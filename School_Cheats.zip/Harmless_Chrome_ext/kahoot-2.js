//copy start
javascript:var nativeWebSocket = window.WebSocket;
let sock;
let msgs = [];
let autocorrectanswer = true;
async function getK(){
let p = prompt("Enter letters/nums behind ?quizId= on teacher screen here(must be exact): ");
var tk = await fetch("https://blooket.schoolcheats.net/api/proxy/play.kahoot.it/rest/kahoots/"+p);
if(tk.status!=200){alert("Hack failed!");window.location.reload();return;}window.k=await tk.json();alert("Hack Started!");
}
getK().then(a=>{
window.WebSocket = function(...args){
  const socket = new nativeWebSocket(...args);
sock=socket;
  socket.addEventListener("message",function(e){var d = JSON.parse(e.data)[0];if(d.channel==="/service/player"){parse(d.data);}});
  socket.sendws = socket.send;
  socket.send=function(d){if(JSON.parse(d)[0].channel==="/service/controller"){if(autocorrectanswer){d=cli(d);}this.sendws(d);}else{this.sendws(d);}}
  alert("Connecting to game...");
  return socket;
};
function cli(m){var msg=JSON.parse(m)[0];if(msg.data.id===45){var c = JSON.parse(msg.data.content);c.choice=correct;msg.data.content=JSON.stringify(c);return JSON.stringify([msg]);}else{return m;}}
function parse(d){msgs.push(d);var c = JSON.parse(d.content);switch(d.id){case 1:console.log("Question recieved!");window.qid=c.questionIndex;if(k){window.correct = k.questions[c.questionIndex].choices.findIndex(e=>e.correct);window.color=colors[correct];console.log(color);console.log("Correct answer: " + k.questions[c.questionIndex].choices[correct].answer);}break;case 2:console.log("Question Started!");break;}}var colors = ["red","blue","yellow","green"];});
//copy end