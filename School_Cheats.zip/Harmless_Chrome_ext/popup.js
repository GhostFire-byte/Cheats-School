async function injectScript(fileName) {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  if (!tab || !tab.id) return;

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (scriptFile) => {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(scriptFile);
      script.onload = () => script.remove();
      document.documentElement.appendChild(script);
    },
    args: [fileName]
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

document.getElementById("blooket").addEventListener("click", async () => {
  await injectScript("blooket.js");
  window.close();
});

document.getElementById("kahoot").addEventListener("click", async () => {
  await injectScript("kahoot-1.js");

  await wait(10000);

  await injectScript("kahoot-2.js");

  window.close();
});